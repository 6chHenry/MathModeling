# README

## 项目文件夹架构

```
.
├── README.md
├── Q1/
│   ├── q1.py
│   ├── Golden_Combination_Analyzer.py
│   ├── Golden_Combination_Processor.py
│   ├── Graphs/
│   │   ├── avg_rating.png
│   │   ├── collaboration_analysis.png
│   │   ├── combined_plot.png
│   │   ├── comprehensive_model_comparison.png
│   │   ├── df_movies_cleaned.png
│   │   ├── genre_runtime_heatmap.png
│   │   ├── genre_runtime_regression.png
│   │   ├── main_genre_mean_rating.png
│   │   ├── rating_vs_runtime.png
│   │   └── runtime_genre_boxplot.png
│   └── Processed_Data/
│       ├── df_movies_cleaned.csv
│       ├── feature_names.txt
│       ├── golden_combinations.json
│       ├── movie_features.npy
│       └── movie_stats.json
├── Q2/
│   ├── q2.py
│   ├── df_result_1.csv
│   ├── DATA_PREPARING/
│   │   ├── DATA_PREPARING.py
│   │   ├── features_and_labels.npz
│   │   └── preprocessor.pkl
│   ├── MODEL_TRAINING/
│   │   ├── XGBOOST_MODEL.py
│   │   ├── features_and_labels.npz
│   │   └── xgb_model.pkl
│   └── PREDICTING/
│       ├── PREDICTING.py
│       ├── predicted_movies.csv
│       ├── preprocessor.pkl
│       └── xgb_model.pkl
├── Q3/
│   ├── q3.py
│   ├── df_result_2.csv
│   ├── Analysis_Data/
│   │   ├── CONSTRAINT_BOUNDARY/
│   │   │   ├── constraint_boundary_analysis.png
│   │   │   └── constraint_boundary_results.csv
│   │   ├── NOISE_RESAMPLEING/
│   │   │   ├── noise_resampling_analysis.png
│   │   │   └── noise_resampling_results.csv
│   │   └── PARAMETER_PERBUTATION/
│   │       ├── parameter_perturbation_analysis.png
│   │       └── parameter_perturbation_results.csv
│   ├── Main_Program/
│   │   ├── milp_copt.py
│   │   └── df_movies_schedule_ours_new.csv
│   └── Utils/
│       ├── parameter_perturbation_testing.py
│       └── q3 draw.py
└── Q4/
    ├── q4.py
    ├── q4_assumation.py
    ├── Results/
    │   ├── day_1.csv
    │   ├── day_2.csv
    │   ├── day_3.csv
    │   ├── day_4.csv
    │   ├── day_5.csv
    │   ├── day_6.csv
    │   └── day_7.csv
    └── Scripts/
        ├── dynamic_params.json
        ├── FINAL_CBC.py
        └── FINAL_COPT.py
```

## 文件说明

### 根目录
- **README.md** - 项目说明文档，包含文件夹架构和文件说明

### Q1/ - 问题1：电影数据分析与黄金组合挖掘
- **q1.py** - 问题1主程序，执行电影数据分析和黄金组合挖掘的主要流程
- **Golden_Combination_Analyzer.py** - 黄金组合分析器，分析电影制作团队的最佳组合
- **Golden_Combination_Processor.py** - 黄金组合处理器，处理和优化黄金组合数据

#### Q1/Graphs/ - 数据可视化图表
- **actors_ratings.png** - 演员评分分析图表
- **avg_rating.png** - 平均评分统计图表
- **collaboration_analysis.png** - 团队合作分析图表
- **combined_plot.png** - 综合分析图表
- **comprehensive_model_comparison.png** - 综合模型比较图表
- **df_movies_cleaned.png** - 清洗后电影数据可视化
- **directors_ratings.png** - 导演评分分析图表
- **genre_runtime_heatmap.png** - 电影类型与运行时间热力图
- **genre_runtime_regression.png** - 电影类型与运行时间回归分析
- **genres_ratings.png** - 电影类型评分分析图表
- **main_genre_mean_rating.png** - 主要电影类型平均评分图表
- **model_evaluation.png** - 模型评估结果图表
- **producers_ratings.png** - 制片人评分分析图表
- **rating_vs_runtime.png** - 评分与运行时间关系图表
- **runtime_genre_boxplot.png** - 运行时间与电影类型箱线图
- **writers_ratings.png** - 编剧评分分析图表

#### Q1/Processed_Data/ - 处理后的数据文件
- **df_movies_cleaned.csv** - 清洗后的电影数据集
- **feature_names.txt** - 特征名称列表
- **golden_combinations.json** - 黄金组合数据
- **movie_features.npy** - 电影特征数据
- **movie_stats.json** - 电影统计数据

### Q2/ - 问题2：电影评分预测模型
- **q2.py** - 问题2主程序，执行电影评分预测的主要流程
- **df_result_1.csv** - 问题2结果数据

#### Q2/DATA_PREPARING/ - 数据准备模块
- **DATA_PREPARING.py** - 数据准备程序，处理原始数据并生成特征
- **features_and_labels.npz** - 特征和标签数据
- **preprocessor.pkl** - 数据预处理器模型

#### Q2/MODEL_TRAINING/ - 模型训练模块
- **XGBOOST_MODEL.py** - XGBoost模型训练程序
- **features_and_labels.npz** - 特征和标签数据
- **xgb_model.pkl** - 训练好的XGBoost模型

#### Q2/PREDICTING/ - 预测模块
- **PREDICTING.py** - 预测程序，使用训练好的模型进行预测
- **predicted_movies.csv** - 预测的电影评分结果
- **preprocessor.pkl** - 数据预处理器模型
- **xgb_model.pkl** - 训练好的XGBoost模型

### Q3/ - 问题3：电影排期优化
- **q3.py** - 问题3主程序，执行电影排期优化的主要流程
- **df_result_2.csv** - 问题3结果数据

#### Q3/Analysis_Data/ - 分析数据
##### Q3/Analysis_Data/CONSTRAINT_BOUNDARY/ - 约束边界分析
- **constraint_boundary_analysis.png** - 约束边界分析可视化
- **constraint_boundary_results.csv** - 约束边界分析结果数据

##### Q3/Analysis_Data/NOISE_RESAMPLEING/ - 噪声重采样分析
- **noise_resampling_analysis.png** - 噪声重采样分析可视化
- **noise_resampling_results.csv** - 噪声重采样分析结果数据

##### Q3/Analysis_Data/PARAMETER_PERBUTATION/ - 参数扰动分析
- **parameter_perturbation_analysis.png** - 参数扰动分析可视化
- **parameter_perturbation_results.csv** - 参数扰动分析结果数据

#### Q3/Main_Program/ - 主程序
- **milp_copt.py** - MILP COPT优化程序，用于电影排期优化
- **df_movies_schedule_ours_new.csv** - 优化后的电影排期数据

#### Q3/Utils/ - 工具程序
- **parameter_perturbation_testing.py** - 参数扰动测试工具
- **q3 draw.py** - Q3绘图工具

### Q4/ - 问题4：动态排期与资源分配
- **q4.py** - 问题4主程序，执行动态排期与资源分配的主要流程
- **q4_assumation.py** - 问题4假设条件设置程序

#### Q4/Results/ - 结果数据
- **day_1.csv** - 第1天排期结果
- **day_2.csv** - 第2天排期结果
- **day_3.csv** - 第3天排期结果
- **day_4.csv** - 第4天排期结果
- **day_5.csv** - 第5天排期结果
- **day_6.csv** - 第6天排期结果
- **day_7.csv** - 第7天排期结果

#### Q4/Scripts/ - 脚本文件
- **dynamic_params.json** - 动态参数配置文件
- **FINAL_CBC.py** - 最终CBC求解程序
- **FINAL_COPT.py** - 最终COPT求解程序
